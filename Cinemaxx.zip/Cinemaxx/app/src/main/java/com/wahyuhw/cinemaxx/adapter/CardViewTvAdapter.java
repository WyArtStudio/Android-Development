package com.wahyuhw.cinemaxx.adapter;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.wahyuhw.cinemaxx.activity.TvShowsDetail;
import com.wahyuhw.cinemaxx.object.TvShows;
import com.wahyuhw.cinemaxx.R;

import java.util.ArrayList;

public class CardViewTvAdapter extends RecyclerView.Adapter<CardViewTvAdapter.CardTvViewHolder> {
    private ArrayList<TvShows> tvData = new ArrayList<>();

    public void setData(ArrayList<TvShows> items) {
        tvData.clear();
        tvData.addAll(items);
        notifyDataSetChanged();
    }


    @NonNull
    @Override
    public CardTvViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int position) {
        View tvView = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_cardview_tvshows, viewGroup, false);
        return new CardTvViewHolder(tvView);
    }

    @Override
    public void onBindViewHolder(@NonNull CardViewTvAdapter.CardTvViewHolder cardTvViewHolder, int position) {
        cardTvViewHolder.bind(tvData.get(position));
    }

    @Override
    public int getItemCount() {
        return tvData.size();
    }

    class CardTvViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ImageView imgPhoto;
        TextView textViewName, textViewDate, textViewScore, textViewOverview;

        CardTvViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewName = itemView.findViewById(R.id.tv_title_ts);
            textViewDate = itemView.findViewById(R.id.tv_year_ts);
            textViewScore = itemView.findViewById(R.id.tv_score_ts);
            textViewOverview = itemView.findViewById(R.id.tv_overview_ts);
            imgPhoto = itemView.findViewById(R.id.iv_poster_ts);

            itemView.setOnClickListener(this);
        }

        void bind(TvShows tvShows) {
            String vote_average = Double.toString(tvShows.getVote_average());
            String url_image = "https://image.tmdb.org/t/p/w185" + tvShows.getPoster_path();

            textViewName.setText(tvShows.getName());
            textViewDate.setText(tvShows.getFirst_air_date());
            textViewOverview.setText(tvShows.getOverview());
            textViewScore.setText(vote_average);

            Glide.with(itemView.getContext())
                    .load(url_image)
                    .placeholder(R.color.colorPrimaryDark)
                    .dontAnimate()
                    .into(imgPhoto);
        }

        @Override
        public void onClick(View v) {
            int position = getAdapterPosition();
            TvShows tvShows = tvData.get(position);

            Intent moveObject = new Intent(itemView.getContext(), TvShowsDetail.class);
            moveObject.putExtra(TvShowsDetail.EXTRA_TV_SHOW, tvShows);
            itemView.getContext().startActivity(moveObject);
        }
    }
}