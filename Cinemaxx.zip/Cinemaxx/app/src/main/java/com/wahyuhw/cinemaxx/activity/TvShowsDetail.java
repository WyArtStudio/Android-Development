package com.wahyuhw.cinemaxx.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.wahyuhw.cinemaxx.object.TvShows;
import com.wahyuhw.cinemaxx.R;

public class TvShowsDetail extends AppCompatActivity {
    public static final String EXTRA_TV_SHOW = "extra_tv_show";

    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tv_shows_detail);

        final TextView tvTitle = findViewById(R.id.tv_title_ts);
        final TextView tvDate = findViewById(R.id.tv_date_ts);
        final TextView tvLanguage = findViewById(R.id.tv_language_ts);
        final TextView tvPopularity = findViewById(R.id.tv_popularity_ts);
        final TextView tvScore = findViewById(R.id.tv_score_ts);
        final TextView tvOverview = findViewById(R.id.tv_overview_ts);
        final ImageView imgPoster = findViewById(R.id.iv_poster_ts);
        final TextView tvOriginalTitle = findViewById(R.id.tv_original_title_ts);

        progressBar = findViewById(R.id.progress_tvshows_detail);
        progressBar.setVisibility(View.VISIBLE);
        final Handler handler = new Handler();

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(5000);
                } catch (Exception e) { }

                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        TvShows tvShows = getIntent().getParcelableExtra(EXTRA_TV_SHOW);

                        String vote_average = Double.toString(tvShows.getVote_average());
                        String popularity = Double.toString(tvShows.getPopularity());
                        String url_image = "https://image.tmdb.org/t/p/w185" + tvShows.getPoster_path();

                        tvTitle.setText(tvShows.getName());
                        tvOverview.setText(tvShows.getFirst_air_date());
                        tvScore.setText(popularity);
                        tvPopularity.setText(vote_average);
                        tvLanguage.setText(tvShows.getOverview());
                        tvDate.setText(tvShows.getOriginal_language());
                        tvOriginalTitle.setText(tvShows.getOriginal_name());

                        Glide.with(TvShowsDetail.this)
                                .load(url_image)
                                .placeholder(R.color.colorPrimaryDark)
                                .dontAnimate()
                                .into(imgPoster);
                        progressBar.setVisibility(View.INVISIBLE);
                    }
                });
            }
        }).start();
    }
}
