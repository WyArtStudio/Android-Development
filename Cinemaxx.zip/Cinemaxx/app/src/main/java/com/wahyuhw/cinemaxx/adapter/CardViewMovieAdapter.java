package com.wahyuhw.cinemaxx.adapter;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.wahyuhw.cinemaxx.object.Movies;
import com.wahyuhw.cinemaxx.activity.MoviesDetailActivity;
import com.wahyuhw.cinemaxx.R;

import java.util.ArrayList;

public class CardViewMovieAdapter extends RecyclerView.Adapter<CardViewMovieAdapter.CardMovieViewHolder> {
    private ArrayList<Movies> mData = new ArrayList<>();

    public void setData(ArrayList<Movies> items) {
        mData.clear();
        mData.addAll(items);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public CardMovieViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int position) {
        View mView = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_cardview_movies, viewGroup, false);
        return new CardMovieViewHolder(mView);
    }

    @Override
    public void onBindViewHolder(@NonNull CardMovieViewHolder cardMovieViewHolder, int position) {
        cardMovieViewHolder.bind(mData.get(position));
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    class CardMovieViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ImageView imgPhoto;
        TextView textViewTitle, textViewYear, textViewScore, textViewGenres, textViewOverview;

        CardMovieViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewTitle = itemView.findViewById(R.id.tv_title);
            textViewYear = itemView.findViewById(R.id.tv_year);
            textViewScore = itemView.findViewById(R.id.tv_score);
            textViewOverview = itemView.findViewById(R.id.tv_genres);
            imgPhoto = itemView.findViewById(R.id.iv_poster);

            itemView.setOnClickListener(this);
        }

        void bind(Movies movies) {
            String vote_average = Double.toString(movies.getVote_average());
            String url_image = "https://image.tmdb.org/t/p/w185" + movies.getPoster();

            textViewTitle.setText(movies.getTitle());
            textViewYear.setText(movies.getRelease_date());
            textViewOverview.setText(movies.getOverview());
            textViewScore.setText(vote_average);

            Glide.with(itemView.getContext())
                    .load(url_image)
                    .placeholder(R.color.colorPrimaryDark)
                    .dontAnimate()
                    .into(imgPhoto);
        }

        @Override
        public void onClick(View v) {
            int position = getAdapterPosition();
            Movies movies = mData.get(position);

            Intent moveObject = new Intent(itemView.getContext(), MoviesDetailActivity.class);
            moveObject.putExtra(MoviesDetailActivity.EXTRA_MOVIE, movies);
            itemView.getContext().startActivity(moveObject);
        }
    }
}
