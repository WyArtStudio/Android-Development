package com.wahyuhw.cinemaxx.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.wahyuhw.cinemaxx.object.Movies;
import com.wahyuhw.cinemaxx.R;

public class MoviesDetailActivity extends AppCompatActivity {
    public static final String EXTRA_MOVIE = "extra_movie";

    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movies_detail);

        final TextView tvTitle = findViewById(R.id.tv_title);
        final TextView tvDate = findViewById(R.id.tv_date);
        final TextView tvOriginalTitle = findViewById(R.id.tv_original_title);
        final TextView tvLanguage = findViewById(R.id.tv_language);
        final TextView tvPopularity = findViewById(R.id.tv_vote_count);
        final TextView tvVoteAverage = findViewById(R.id.tv_score);
        final TextView tvSynopsis = findViewById(R.id.tv_synopsis);
        final ImageView imgPoster = findViewById(R.id.iv_poster);

        progressBar = findViewById(R.id.progress_movies_detail);
        progressBar.setVisibility(View.VISIBLE);
        final Handler handler = new Handler();

        new Thread(new Runnable() {
            public void run() {
                try {
                    Thread.sleep(5000);
                } catch (Exception e) { }

                handler.post(new Runnable() {
                    public void run() {
                        Movies movies = getIntent().getParcelableExtra(EXTRA_MOVIE);

                        String popularity = Double.toString(movies.getPopularity());
                        String vote_average = Double.toString(movies.getVote_average());
                        String url_image = "https://image.tmdb.org/t/p/w185" + movies.getPoster();

                        tvTitle.setText(movies.getTitle());
                        tvSynopsis.setText(movies.getRelease_date());
                        tvVoteAverage.setText(popularity);
                        tvPopularity.setText(vote_average);
                        tvLanguage.setText(movies.getOverview());
                        tvDate.setText(movies.getOriginal_language());
                        tvOriginalTitle.setText(movies.getOriginal_title());

                        Glide.with(MoviesDetailActivity.this)
                                .load(url_image)
                                .placeholder(R.color.colorPrimaryDark)
                                .dontAnimate()
                                .into(imgPoster);
                        progressBar.setVisibility(View.INVISIBLE);
                    }
                });
            }
        }).start();
    }
}
