package com.wahyuhw.cinemaxx.object;

import android.os.Parcel;
import android.os.Parcelable;

import org.json.JSONObject;

public class TvShows implements Parcelable {
    private String original_language;
    private String overview;
    private Double vote_average;
    private Double popularity;
    private String status;
    private String name;
    private String original_name;
    private String first_air_date;
    private String poster_path;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOriginal_name() {
        return original_name;
    }

    public void setOriginal_name(String original_name) {
        this.original_name = original_name;
    }

    public String getFirst_air_date() {
        return first_air_date;
    }

    public void setFirst_air_date(String first_air_date) {
        this.first_air_date = first_air_date;
    }

    public String getPoster_path() {
        return poster_path;
    }

    public void setPoster_path(String poster_path) {
        this.poster_path = poster_path;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getOriginal_language() {
        return original_language;
    }

    public void setOriginal_language(String original_language) {
        this.original_language = original_language;
    }

    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }

    public Double getVote_average() {
        return vote_average;
    }

    public void setVote_average(Double vote_average) {
        this.vote_average = vote_average;
    }

    public Double getPopularity() {
        return popularity;
    }

    public void setPopularity(Double popularity) {
        this.popularity = popularity;
    }

    protected TvShows(Parcel in) {
        this.name = in.readString();
        this.poster_path = in.readString();
        this.original_language = in.readString();
        this.first_air_date = in.readString();
        this.overview = in.readString();
        this.popularity = (Double) in.readValue((Double.class.getClassLoader()));
        this.vote_average = (Double) in.readValue(Double.class.getClassLoader());
        this.original_name = in.readString();
    }

    public static final Parcelable.Creator<TvShows> CREATOR = new Parcelable.Creator<TvShows>() {
        @Override
        public TvShows createFromParcel(Parcel in) {
            return new TvShows(in);
        }

        @Override
        public TvShows[] newArray(int size) {
            return new TvShows[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.name);
        dest.writeString(this.poster_path);
        dest.writeString(this.first_air_date);
        dest.writeString(this.overview);
        dest.writeString(this.original_language);
        dest.writeValue(this.vote_average);
        dest.writeValue(this.popularity);
        dest.writeString(this.original_name);
    }

    public TvShows(JSONObject object) {
        try {
            String name = object.getString("name");
            String poster_path = object.getString("poster_path");
            String original_language = object.getString("original_language");
            String overview = object.getString("overview");
            String first_air_date = object.getString("first_air_date");
            Double vote_average = object.getDouble("vote_average");
            Double popularity = object.getDouble("popularity");
            String original_name = object.getString("original_name");

            this.name = name;
            this.poster_path = poster_path;
            this.original_language = original_language;
            this.overview = overview;
            this.first_air_date = first_air_date;
            this.vote_average = vote_average;
            this.popularity = popularity;
            this.original_name = original_name;

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
