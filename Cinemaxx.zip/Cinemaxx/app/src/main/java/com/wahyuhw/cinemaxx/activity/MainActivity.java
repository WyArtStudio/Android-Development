package com.wahyuhw.cinemaxx.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Menu;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.wahyuhw.cinemaxx.R;
import com.wahyuhw.cinemaxx.fragment.FavoriteMoviesFragment;
import com.wahyuhw.cinemaxx.fragment.FavoriteTvShowsFragment;
import com.wahyuhw.cinemaxx.fragment.MoviesFragment;
import com.wahyuhw.cinemaxx.fragment.TvShowsFragment;

public class MainActivity extends AppCompatActivity {
    private FragmentManager fragmentManager;
    private FragmentTransaction fragmentTransaction;
    private MoviesFragment movieFragment;
    private TvShowsFragment tvShowFragment;
    private FavoriteMoviesFragment favoriteMovieFragment;
    private FavoriteTvShowsFragment favoriteTvShowFragment;
    private String title;
    private final String STATE_TITLE = "state_string";
    private final String STATE_MODE = "state_mode";

    private int mode = R.id.navigation_movies;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        title = getResources().getString(R.string.title1);

        BottomNavigationView navView = findViewById(R.id.nav_view);
        navView.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        fragmentManager = getSupportFragmentManager();
        movieFragment = new MoviesFragment();
        tvShowFragment = new TvShowsFragment();

        favoriteMovieFragment = new FavoriteMoviesFragment();
        favoriteTvShowFragment = new FavoriteTvShowsFragment();

        if (savedInstanceState != null){
            mode = savedInstanceState.getInt(STATE_MODE);
            title = savedInstanceState.getString(STATE_TITLE);

            if (mode == R.id.navigation_movies){
                setToMoviesFragment();
            } else if (mode == R.id.navigation_tvshows){
                setToTvShowsFragment();
            } else if (mode == R.id.navigation_favorite_movie){
                setToFavoriteMoviesFragment();
            }
            else {
                setToFavoriteTvShowsFragment();
            }
        } else {
            setToMoviesFragment();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(STATE_MODE, mode);
        outState.putString(STATE_TITLE, title);
    }

    private void setToMoviesFragment() {
        setTitle(title);

        fragmentTransaction = fragmentManager.beginTransaction();
        Fragment fragment = fragmentManager.findFragmentByTag(MoviesFragment.class.getSimpleName());

        if (!(fragment instanceof MoviesFragment)) {
            fragmentTransaction.replace(
                    R.id.linear_layout_container,
                    movieFragment,
                    MoviesFragment.class.getSimpleName()
            );
            fragmentTransaction.commit();
        }
    }

    private void setToTvShowsFragment() {
        setTitle(title);

        fragmentTransaction = fragmentManager.beginTransaction();
        Fragment fragment = fragmentManager.findFragmentByTag(TvShowsFragment.class.getSimpleName());

        if (!(fragment instanceof TvShowsFragment)) {
            fragmentTransaction.replace(
                    R.id.linear_layout_container,
                    tvShowFragment,
                    TvShowsFragment.class.getSimpleName()
            );
            fragmentTransaction.commit();
        }
    }

    private void setToFavoriteTvShowsFragment() {
        setTitle(title);

        fragmentTransaction = fragmentManager.beginTransaction();
        Fragment fragment = fragmentManager.findFragmentByTag(FavoriteTvShowsFragment.class.getSimpleName());

        if (!(fragment instanceof FavoriteTvShowsFragment)) {
            fragmentTransaction.replace(
                    R.id.linear_layout_container,
                    favoriteTvShowFragment,
                    FavoriteTvShowsFragment.class.getSimpleName()
            );
            fragmentTransaction.commit();
        }
    }

    private void setToFavoriteMoviesFragment() {
        setTitle(title);

        fragmentTransaction = fragmentManager.beginTransaction();
        Fragment fragment = fragmentManager.findFragmentByTag(FavoriteMoviesFragment.class.getSimpleName());

        if (!(fragment instanceof FavoriteMoviesFragment)) {
            fragmentTransaction.replace(
                    R.id.linear_layout_container,
                    favoriteMovieFragment,
                    FavoriteMoviesFragment.class.getSimpleName()
            );
            fragmentTransaction.commit();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_change_settings) {
            Intent mIntent = new Intent(Settings.ACTION_LOCALE_SETTINGS);
            startActivity(mIntent);
        }
        return super.onOptionsItemSelected(item);
    }

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_movies:
                    title = getResources().getString(R.string.title1);
                    mode = item.getItemId();

                    setToMoviesFragment();
                    return true;
                case R.id.navigation_tvshows:
                    title = getResources().getString(R.string.title2);
                    mode = item.getItemId();

                    setToTvShowsFragment();
                    return true;

                case R.id.navigation_favorite_movie:
                    title = getResources().getString(R.string.title3);
                    mode = item.getItemId();

                    setToFavoriteMoviesFragment();
                    return true;

                case R.id.navigation_favorite_tv:
                    title = getResources().getString(R.string.title4);
                    mode = item.getItemId();

                    setToFavoriteTvShowsFragment();
                    return true;
            }
            return false;
        }
    };
}
