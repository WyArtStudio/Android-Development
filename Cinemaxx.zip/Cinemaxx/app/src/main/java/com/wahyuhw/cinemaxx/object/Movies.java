package com.wahyuhw.cinemaxx.object;

import android.os.Parcel;
import android.os.Parcelable;

import org.json.JSONObject;

public class Movies implements Parcelable {
    private String title;
    private String poster;
    private String original_language;
    private String overview;
    private String release_date;
    private Double vote_average;
    private Double popularity;
    private String original_title;

    public String getOriginal_title() {
        return original_title;
    }

    public void setOriginal_title(String original_title) {
        this.original_title = original_title;
    }

    public Double getPopularity() {
        return popularity;
    }

    public void setPopularity(Double popularity) {
        this.popularity = popularity;
    }

    public Double getVote_average() {
        return vote_average;
    }

    public void setVote_average(Double vote_average) {
        this.vote_average = vote_average;
    }


    public String getOriginal_language() {
        return original_language;
    }

    public void setOriginal_language(String original_language) {
        this.original_language = original_language;
    }

    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }

    public String getRelease_date() {
        return release_date;
    }

    public void setRelease_date(String release_date) {
        this.release_date = release_date;
    }

    protected Movies(Parcel in) {
        this.title = in.readString();
        this.poster = in.readString();
        this.original_language = in.readString();
        this.release_date = in.readString();
        this.overview = in.readString();
        this.popularity = (Double) in.readValue((Double.class.getClassLoader()));
        this.vote_average = (Double) in.readValue(Double.class.getClassLoader());
        this.original_title = in.readString();
    }

    public static final Creator<Movies> CREATOR = new Creator<Movies>() {
        @Override
        public Movies createFromParcel(Parcel in) {
            return new Movies(in);
        }

        @Override
        public Movies[] newArray(int size) {
            return new Movies[size];
        }
    };

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPoster() {
        return poster;
    }

    public void setPoster(String poster) {
        this.poster = poster;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.title);
        dest.writeString(this.poster);
        dest.writeString(this.release_date);
        dest.writeString(this.overview);
        dest.writeString(this.original_language);
        dest.writeValue(this.vote_average);
        dest.writeValue(this.popularity);
        dest.writeString(this.original_title);
    }

    public Movies(JSONObject object) {
        try {
            String title = object.getString("title");
            String poster_path = object.getString("poster_path");
            String original_language = object.getString("original_language");
            String overview = object.getString("overview");
            String release_date = object.getString("release_date");
            Double vote_average = object.getDouble("vote_average");
            Double popularity = object.getDouble("popularity");
            String original_title = object.getString("original_title");

            this.title = title;
            this.poster = poster_path;
            this.original_language = original_language;
            this.overview = overview;
            this.release_date = release_date;
            this.vote_average = vote_average;
            this.popularity = popularity;
            this.original_title = original_title;

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}