package com.wahyuhw.cinemaxx.fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import com.wahyuhw.cinemaxx.adapter.CardViewTvAdapter;
import com.wahyuhw.cinemaxx.object.TvShows;
import com.wahyuhw.cinemaxx.R;
import com.wahyuhw.cinemaxx.viewmodel.TvShowsViewModel;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class TvShowsFragment extends Fragment {
    private ProgressBar progressBar;
    private CardViewTvAdapter adapter;

    public TvShowsFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        adapter = new CardViewTvAdapter();
        View view = inflater.inflate(R.layout.fragment_tv_shows, container, false);
        RecyclerView recyclerView = view.findViewById(R.id.rv_list_tv);
        recyclerView.setLayoutManager(new LinearLayoutManager(this.getContext()));
        recyclerView.setAdapter(adapter);

        progressBar = view.findViewById(R.id.progressBar);

        TvShowsViewModel tvShowsViewModel = ViewModelProviders.of(this).get(TvShowsViewModel.class);
        tvShowsViewModel.getTvShows().observe(this, getTvShow);
        tvShowsViewModel.setTvShows("EXTRA_TV_SHOW");

        showLoading(true);

        return view;
    }

    private Observer<ArrayList<TvShows>> getTvShow = new Observer<ArrayList<TvShows>>() {
        @Override
        public void onChanged(ArrayList<TvShows> tvShows) {
            if (tvShows != null) {
                adapter.setData(tvShows);
            }
            showLoading(false);
        }
    };

    private void showLoading(Boolean state) {
        if (state) {
            progressBar.setVisibility(View.VISIBLE);
        } else {
            progressBar.setVisibility(View.GONE);
        }
    }
}